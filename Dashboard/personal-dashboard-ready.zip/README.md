# Personal Dashboard

A self-contained personal dashboard designed to run as a static Netlify site and install nicely on a phone home screen.

The main app is `index.html`. It includes a daily goal ticker, day progress ring, today and tomorrow goal planning, local persistence, and Netlify-backed cross-device sync.

## Features

- Single-file dashboard UI with no build step.
- Today and tomorrow goal lists with edit, delete, reorder, queue, and push-to-tomorrow actions.
- NASDAQ-style pending goal ticker.
- Day progress ring based on an 8 AM to midnight awake window.
- Local `localStorage` persistence for offline-friendly use.
- Optional cross-device sync through a zero-dependency Netlify Function and Netlify Blobs.
- Extra weight dashboard HTML files from the source dashboard repo.

## Files

- `index.html` - main personal dashboard.
- `netlify.toml` - tells Netlify to publish the root folder and include functions.
- `netlify/functions/store.mjs` - sync endpoint used by the dashboard.
- `weight1.html` and `weight102.html` - additional weight dashboard pages from the reference repo.
- `tutorial-prompt (3).md` - original tutorial prompt.
- `Phone and computer data sync` - original sync-change prompt from the reference repo.

## Deploy To Netlify

1. Open your site in Netlify.
2. Go to the Deploys page.
3. Drag the whole project folder onto Netlify, not just `index.html`.
4. After deploy, hard-refresh the dashboard on every device.
5. Visit `https://YOUR-SITE.netlify.app/.netlify/functions/store`.

The sync endpoint should return `{}` or saved dashboard data. It should not show a crash page.

## Notes

The dashboard syncs goal data only:

- `goals:YYYY-MM-DD`
- `goal_streak_v1`

It intentionally does not sync API keys, secrets, or device-only settings.
